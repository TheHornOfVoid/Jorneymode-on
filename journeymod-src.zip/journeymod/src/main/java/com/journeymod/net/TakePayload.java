package com.journeymod.net;

import com.journeymod.JourneyMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/**
 * Клиент -> сервер: взять предмет из меню.
 * mode 0 = один предмет на курсор, 1 = полный стак на курсор, 2 = полный стак сразу в инвентарь.
 */
public record TakePayload(ItemStack stack, int mode) implements CustomPacketPayload {
    public static final Type<TakePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(JourneyMod.MODID, "take"));
    public static final StreamCodec<RegistryFriendlyByteBuf, TakePayload> CODEC = StreamCodec.composite(
            ItemStack.STREAM_CODEC, TakePayload::stack,
            ByteBufCodecs.VAR_INT, TakePayload::mode,
            TakePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
