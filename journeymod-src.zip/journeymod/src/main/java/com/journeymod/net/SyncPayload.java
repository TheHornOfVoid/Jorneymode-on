package com.journeymod.net;

import com.journeymod.JourneyMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** Сервер -> клиент: часть списка изученных предметов (reset = начать список заново). */
public record SyncPayload(boolean reset, List<ItemStack> items) implements CustomPacketPayload {
    public static final Type<SyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(JourneyMod.MODID, "sync"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SyncPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, SyncPayload::reset,
            ItemStack.LIST_STREAM_CODEC, SyncPayload::items,
            SyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
