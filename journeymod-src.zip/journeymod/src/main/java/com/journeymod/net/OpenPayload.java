package com.journeymod.net;

import com.journeymod.JourneyMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Клиент -> сервер: «открой мне меню». */
public record OpenPayload() implements CustomPacketPayload {
    public static final Type<OpenPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(JourneyMod.MODID, "open"));
    public static final StreamCodec<RegistryFriendlyByteBuf, OpenPayload> CODEC = StreamCodec.unit(new OpenPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
