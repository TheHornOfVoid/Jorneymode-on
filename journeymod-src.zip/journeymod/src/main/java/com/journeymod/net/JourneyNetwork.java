package com.journeymod.net;

import com.journeymod.menu.JourneyMenu;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class JourneyNetwork {
    private JourneyNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(OpenPayload.TYPE, OpenPayload.CODEC, JourneyNetwork::handleOpen);
        registrar.playToServer(TakePayload.TYPE, TakePayload.CODEC, JourneyNetwork::handleTake);
        registrar.playToClient(SyncPayload.TYPE, SyncPayload.CODEC, JourneyNetwork::handleSync);
    }

    private static void handleOpen(OpenPayload payload, IPayloadContext ctx) {
        if (ctx.player() instanceof ServerPlayer player && !player.isSpectator()) {
            JourneyMenu.open(player);
        }
    }

    private static void handleTake(TakePayload payload, IPayloadContext ctx) {
        if (ctx.player() instanceof ServerPlayer player && player.containerMenu instanceof JourneyMenu menu) {
            menu.take(payload.stack(), payload.mode());
        }
    }

    private static void handleSync(SyncPayload payload, IPayloadContext ctx) {
        if (ctx.player().containerMenu instanceof JourneyMenu menu) {
            menu.clientSync(payload.reset(), payload.items());
        }
    }
}
