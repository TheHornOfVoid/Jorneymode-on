package com.journeymod;

import com.journeymod.menu.JourneyMenu;
import com.journeymod.net.JourneyNetwork;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(JourneyMod.MODID)
public class JourneyMod {
    public static final String MODID = "journeymod";

    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, MODID);

    public static final DeferredHolder<MenuType<?>, MenuType<JourneyMenu>> JOURNEY_MENU =
            MENUS.register("journey", () -> new MenuType<JourneyMenu>(JourneyMenu::new, FeatureFlags.DEFAULT_FLAGS));

    public JourneyMod(IEventBus modBus) {
        MENUS.register(modBus);
        modBus.addListener(JourneyNetwork::register);
    }
}
