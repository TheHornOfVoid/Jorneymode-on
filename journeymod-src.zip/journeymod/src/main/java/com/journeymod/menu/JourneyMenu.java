package com.journeymod.menu;

import com.journeymod.JourneyMod;
import com.journeymod.data.JourneyData;
import com.journeymod.net.SyncPayload;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Меню путешествия.
 * <ul>
 *   <li>Слот 0 — слот «изучения»: предмет, положенный сюда, навсегда добавляется в список.
 *       Если предмет уже изучен, то положенный стак просто уничтожается (корзина).</li>
 *   <li>Слоты 1..36 — инвентарь игрока.</li>
 *   <li>Сетка изученных предметов рисуется экраном; клики по ней идут через {@link com.journeymod.net.TakePayload}.</li>
 * </ul>
 */
public class JourneyMenu extends AbstractContainerMenu {
    public static final int DEPOSIT_SLOT = 0;
    public static final int DEPOSIT_X = 153;
    public static final int DEPOSIT_Y = 15;
    public static final int INV_Y = 145;

    private static final int SYNC_CHUNK = 1000;

    private final Player player;
    /** На сервере — живой список из JourneyData, на клиенте — собственная копия. */
    private final List<ItemStack> unlocked;
    private final JourneyData data; // null на клиенте
    private final SimpleContainer depositContainer;
    private int revision;

    /** Клиентский конструктор (вызывается самим Minecraft). */
    public JourneyMenu(int id, Inventory inventory) {
        this(id, inventory, new ArrayList<>(), null);
    }

    /** Серверный конструктор. */
    public JourneyMenu(int id, Inventory inventory, JourneyData data) {
        this(id, inventory, data.items(), data);
    }

    private JourneyMenu(int id, Inventory inventory, List<ItemStack> unlocked, JourneyData data) {
        super(JourneyMod.JOURNEY_MENU.get(), id);
        this.player = inventory.player;
        this.unlocked = unlocked;
        this.data = data;
        this.depositContainer = new SimpleContainer(1) {
            @Override
            public void setChanged() {
                super.setChanged();
                onDepositChanged();
            }
        };

        addSlot(new DepositSlot(depositContainer, 0, DEPOSIT_X, DEPOSIT_Y));
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9 + 9, 9 + col * 18, INV_Y + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 9 + col * 18, INV_Y + 58));
        }
    }

    // ------------------------------------------------------------------ открытие

    public static void open(ServerPlayer player) {
        JourneyData data = JourneyData.get(player.server);
        var result = player.openMenu(new SimpleMenuProvider(
                (id, inv, p) -> new JourneyMenu(id, inv, data),
                Component.translatable("menu.journeymod.title")));
        if (result.isEmpty()) {
            return;
        }
        List<ItemStack> all = data.items();
        if (all.isEmpty()) {
            PacketDistributor.sendToPlayer(player, new SyncPayload(true, List.of()));
            return;
        }
        for (int i = 0; i < all.size(); i += SYNC_CHUNK) {
            List<ItemStack> chunk = new ArrayList<>(all.subList(i, Math.min(all.size(), i + SYNC_CHUNK)));
            PacketDistributor.sendToPlayer(player, new SyncPayload(i == 0, chunk));
        }
    }

    // ------------------------------------------------------------------ список

    public List<ItemStack> unlocked() {
        return unlocked;
    }

    public int revision() {
        return revision;
    }

    public boolean isUnlocked(ItemStack stack) {
        for (ItemStack s : unlocked) {
            if (ItemStack.isSameItemSameComponents(s, stack)) {
                return true;
            }
        }
        return false;
    }

    /** Клиент: применить пришедшую от сервера часть списка. */
    public void clientSync(boolean reset, List<ItemStack> items) {
        if (data != null) {
            return; // серверная копия уже общая
        }
        if (reset) {
            unlocked.clear();
        }
        for (ItemStack stack : items) {
            if (!isUnlocked(stack)) {
                unlocked.add(stack);
            }
        }
        revision++;
    }

    // ------------------------------------------------------------------ слот изучения

    private void onDepositChanged() {
        ItemStack stack = depositContainer.getItem(0);
        if (stack.isEmpty()) {
            return;
        }
        if (player.level().isClientSide()) {
            // предсказание на клиенте: предмет «поглощается» сразу
            depositContainer.setItem(0, ItemStack.EMPTY);
            return;
        }
        ItemStack template = JourneyData.normalize(stack);
        boolean added = data.add(template);
        depositContainer.setItem(0, ItemStack.EMPTY);
        if (added && player instanceof ServerPlayer sp) {
            for (ServerPlayer other : sp.server.getPlayerList().getPlayers()) {
                if (other.containerMenu instanceof JourneyMenu) {
                    PacketDistributor.sendToPlayer(other, new SyncPayload(false, List.of(template)));
                }
            }
        }
    }

    private class DepositSlot extends Slot {
        DepositSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return true;
        }

        @Override
        public int getMaxStackSize(ItemStack stack) {
            // новый предмет: принимается ровно один. Уже изученный: можно выбросить весь стак.
            return isUnlocked(stack) ? super.getMaxStackSize(stack) : 1;
        }
    }

    // ------------------------------------------------------------------ взятие предметов

    /** Сервер: игрок кликнул по предмету в сетке. */
    public void take(ItemStack requested, int mode) {
        if (data == null || requested.isEmpty()) {
            return;
        }
        ItemStack entry = data.find(requested);
        if (entry == null) {
            return; // нельзя взять то, что не изучено
        }
        int max = Math.max(1, entry.getMaxStackSize());

        if (mode == 2) {
            player.getInventory().placeItemBackInInventory(entry.copyWithCount(max));
            return;
        }

        ItemStack carried = getCarried();
        if (carried.isEmpty()) {
            setCarried(entry.copyWithCount(mode == 1 ? max : 1));
        } else if (ItemStack.isSameItemSameComponents(carried, entry)) {
            int count = mode == 1 ? max : Math.min(max, carried.getCount() + 1);
            if (count > carried.getCount()) {
                setCarried(entry.copyWithCount(count));
            }
        }
        // в руке другой предмет: ничего не делаем, чтобы случайно не удалить его
    }

    // ------------------------------------------------------------------ стандартное

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        if (index == DEPOSIT_SLOT || index >= slots.size()) {
            return ItemStack.EMPTY;
        }
        Slot slot = slots.get(index);
        if (slot.hasItem()) {
            ItemStack stack = slot.getItem();
            if (!isUnlocked(stack)) {
                // Shift+клик по новому предмету: изучить, потратив одну штуку
                depositContainer.setItem(0, stack.split(1));
                slot.setChanged();
            }
        }
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public void removed(Player player) {
        super.removed(player); // вернёт предмет с курсора в инвентарь
        clearContainer(player, depositContainer);
    }
}
