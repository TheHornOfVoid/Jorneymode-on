package com.journeymod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;

/**
 * Список «изученных» предметов одного мира. Хранится в данных Overworld
 * (world/data/journeymod_unlocked.dat), поэтому у каждого мира он свой.
 */
public class JourneyData extends SavedData {
    private static final String NAME = "journeymod_unlocked";

    public static final SavedData.Factory<JourneyData> FACTORY =
            new SavedData.Factory<>(JourneyData::new, JourneyData::load, null);

    private final List<ItemStack> items = new ArrayList<>();

    public static JourneyData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(FACTORY, NAME);
    }

    /** Предмет-шаблон: количество 1, без прочности (чтобы сломанный инструмент не считался отдельным). */
    public static ItemStack normalize(ItemStack stack) {
        ItemStack copy = stack.copyWithCount(1);
        copy.remove(DataComponents.DAMAGE);
        return copy;
    }

    public List<ItemStack> items() {
        return items;
    }

    public ItemStack find(ItemStack stack) {
        for (ItemStack s : items) {
            if (ItemStack.isSameItemSameComponents(s, stack)) {
                return s;
            }
        }
        return null;
    }

    /** @return true, если предмет был новым и добавлен. */
    public boolean add(ItemStack stack) {
        ItemStack norm = normalize(stack);
        if (norm.isEmpty() || find(norm) != null) {
            return false;
        }
        items.add(norm);
        setDirty();
        return true;
    }

    public static JourneyData load(CompoundTag tag, HolderLookup.Provider registries) {
        JourneyData data = new JourneyData();
        RegistryOps<Tag> ops = registries.createSerializationContext(NbtOps.INSTANCE);
        ListTag list = tag.getList("items", Tag.TAG_COMPOUND);
        for (Tag entry : list) {
            // Предметы удалённых модов не распарсятся и будут молча пропущены.
            ItemStack.CODEC.parse(ops, entry).result().ifPresent(stack -> {
                if (data.find(stack) == null) {
                    data.items.add(stack);
                }
            });
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        RegistryOps<Tag> ops = registries.createSerializationContext(NbtOps.INSTANCE);
        ListTag list = new ListTag();
        for (ItemStack stack : items) {
            ItemStack.CODEC.encodeStart(ops, stack).result().ifPresent(list::add);
        }
        tag.put("items", list);
        return tag;
    }
}
