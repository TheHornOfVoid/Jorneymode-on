package com.journeymod.client;

import com.journeymod.menu.JourneyMenu;
import com.journeymod.net.TakePayload;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Экран меню путешествия: поиск, сетка изученных предметов с прокруткой, слот изучения и инвентарь.
 * <p>ЛКМ/ПКМ — взять 1 предмет, СКМ (колёсико) — взять полный стак, Shift+клик — полный стак сразу в инвентарь.
 * Количество на иконках не рисуется.</p>
 */
public class JourneyScreen extends AbstractContainerScreen<JourneyMenu> {
    private static final int COLS = 9;
    private static final int ROWS = 5;
    private static final int GRID_X = 9;
    private static final int GRID_Y = 37;
    private static final int SB_X = 175;
    private static final int SB_W = 10;
    private static final int SB_H = ROWS * 18;

    private EditBox search;
    private String savedSearch = "";
    private List<ItemStack> filtered = new ArrayList<>();
    private int cachedRevision = -1;
    private String cachedQuery = null;
    private int scrollRow;
    private boolean draggingBar;

    public JourneyScreen(JourneyMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 194;
        this.imageHeight = 226;
        this.titleLabelX = 8;
        this.titleLabelY = 5;
        this.inventoryLabelX = 8;
        this.inventoryLabelY = 134;
    }

    @Override
    protected void init() {
        super.init();
        search = new EditBox(font, leftPos + GRID_X, topPos + 17, 132, 13, Component.translatable("menu.journeymod.search"));
        search.setMaxLength(50);
        search.setHint(Component.translatable("menu.journeymod.search"));
        search.setValue(savedSearch);
        search.setResponder(text -> {
            savedSearch = text;
            scrollRow = 0;
        });
        addRenderableWidget(search);
        cachedQuery = null;
    }

    // ------------------------------------------------------------------ фильтр и прокрутка

    private void refreshFilter() {
        String query = search.getValue().trim().toLowerCase(Locale.ROOT);
        if (menu.revision() == cachedRevision && query.equals(cachedQuery)) {
            return;
        }
        cachedRevision = menu.revision();
        cachedQuery = query;
        List<ItemStack> source = menu.unlocked();
        filtered = new ArrayList<>();
        for (ItemStack stack : source) {
            if (query.isEmpty() || matches(stack, query)) {
                filtered.add(stack);
            }
        }
        scrollRow = Math.min(scrollRow, maxScroll());
    }

    private static boolean matches(ItemStack stack, String query) {
        if (stack.getHoverName().getString().toLowerCase(Locale.ROOT).contains(query)) {
            return true;
        }
        return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString().contains(query);
    }

    private int totalRows() {
        return (filtered.size() + COLS - 1) / COLS;
    }

    private int maxScroll() {
        return Math.max(0, totalRows() - ROWS);
    }

    private int thumbHeight() {
        int total = Math.max(totalRows(), 1);
        return Math.max(10, SB_H * Math.min(ROWS, total) / total);
    }

    private void scrollFromMouse(double mouseY) {
        int max = maxScroll();
        if (max == 0) {
            scrollRow = 0;
            return;
        }
        double track = SB_H - thumbHeight();
        double rel = (mouseY - (topPos + GRID_Y) - thumbHeight() / 2.0) / track;
        scrollRow = (int) Math.round(Math.max(0, Math.min(1, rel)) * max);
    }

    // ------------------------------------------------------------------ геометрия сетки

    /** Индекс в filtered под курсором, -1 если курсор над пустой ячейкой, -2 если вне сетки. */
    private int gridIndexAt(double mouseX, double mouseY) {
        double x = mouseX - (leftPos + GRID_X);
        double y = mouseY - (topPos + GRID_Y);
        if (x < 0 || y < 0 || x >= COLS * 18 || y >= ROWS * 18) {
            return -2;
        }
        int index = (scrollRow + (int) (y / 18)) * COLS + (int) (x / 18);
        return index < filtered.size() ? index : -1;
    }

    private boolean overScrollbar(double mouseX, double mouseY) {
        return mouseX >= leftPos + SB_X && mouseX < leftPos + SB_X + SB_W
                && mouseY >= topPos + GRID_Y && mouseY < topPos + GRID_Y + SB_H;
    }

    // ------------------------------------------------------------------ рисование

    private static void slotFrame(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 18, y + 18, 0xFF373737);
        g.fill(x + 1, y + 1, x + 18, y + 18, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 17, y + 17, 0xFF8B8B8B);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        refreshFilter();
        int x = leftPos;
        int y = topPos;

        // панель
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF000000);
        g.fill(x + 1, y + 1, x + imageWidth - 1, y + imageHeight - 1, 0xFFFFFFFF);
        g.fill(x + 2, y + 2, x + imageWidth - 1, y + imageHeight - 1, 0xFF555555);
        g.fill(x + 2, y + 2, x + imageWidth - 2, y + imageHeight - 2, 0xFFC6C6C6);

        // рамки обычных слотов (слот изучения + инвентарь)
        for (Slot slot : menu.slots) {
            slotFrame(g, x + slot.x - 1, y + slot.y - 1);
        }

        // сетка
        int hovered = gridIndexAt(mouseX, mouseY);
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                int cellX = x + GRID_X + col * 18;
                int cellY = y + GRID_Y + row * 18;
                slotFrame(g, cellX - 1, cellY - 1);
                int index = (scrollRow + row) * COLS + col;
                if (index < filtered.size()) {
                    // renderItem без renderItemDecorations: ни количества, ни полоски прочности
                    g.renderItem(filtered.get(index), cellX, cellY);
                    if (index == hovered) {
                        g.fill(cellX, cellY, cellX + 16, cellY + 16, 0x80FFFFFF);
                    }
                }
            }
        }

        // полоса прокрутки
        int sbX = x + SB_X;
        int sbY = y + GRID_Y;
        g.fill(sbX, sbY, sbX + SB_W, sbY + SB_H, 0xFF373737);
        int thumbH = thumbHeight();
        int max = maxScroll();
        int thumbY = max == 0 ? 0 : (SB_H - thumbH) * scrollRow / max;
        g.fill(sbX + 1, sbY + thumbY + 1, sbX + SB_W - 1, sbY + thumbY + thumbH - 1,
                max == 0 ? 0xFF6B6B6B : 0xFFE0E0E0);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int index = gridIndexAt(mouseX, mouseY);
        if (index >= 0) {
            g.renderTooltip(font, filtered.get(index), mouseX, mouseY);
        } else if (hoveredSlot != null && hoveredSlot.index == JourneyMenu.DEPOSIT_SLOT
                && !hoveredSlot.hasItem() && menu.getCarried().isEmpty()) {
            g.renderTooltip(font, Component.translatable("menu.journeymod.deposit_hint"), mouseX, mouseY);
        }
    }

    // ------------------------------------------------------------------ ввод

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int index = gridIndexAt(mouseX, mouseY);
        if (index != -2) {
            search.setFocused(false);
            if (index >= 0 && button >= 0 && button <= 2) {
                int mode = button == 2 ? 1 : (hasShiftDown() ? 2 : 0);
                PacketDistributor.sendToServer(new TakePayload(filtered.get(index), mode));
            }
            return true;
        }
        if (button == 0 && overScrollbar(mouseX, mouseY)) {
            draggingBar = true;
            scrollFromMouse(mouseY);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (draggingBar) {
            scrollFromMouse(mouseY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingBar = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (maxScroll() > 0 && scrollY != 0) {
            scrollRow = Math.max(0, Math.min(maxScroll(), scrollRow - (int) Math.signum(scrollY)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (search.isFocused() && keyCode != GLFW.GLFW_KEY_ESCAPE) {
            // пока печатаем в поиске, «E» и прочие клавиши не должны закрывать экран
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                search.setFocused(false);
            } else {
                search.keyPressed(keyCode, scanCode, modifiers);
            }
            return true;
        }
        if (ClientEvents.OPEN_KEY.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
