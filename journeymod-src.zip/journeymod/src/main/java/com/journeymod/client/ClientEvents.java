package com.journeymod.client;

import com.journeymod.JourneyMod;
import com.journeymod.net.OpenPayload;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

public final class ClientEvents {
    private ClientEvents() {}

    /** Клавиша открытия меню. Меняется в Настройки -> Управление -> «Меню путешествия». */
    public static final KeyMapping OPEN_KEY = new KeyMapping(
            "key.journeymod.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.journeymod");

    @EventBusSubscriber(modid = JourneyMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(OPEN_KEY);
        }

        @SubscribeEvent
        public static void registerScreens(RegisterMenuScreensEvent event) {
            event.register(JourneyMod.JOURNEY_MENU.get(), JourneyScreen::new);
        }
    }

    @EventBusSubscriber(modid = JourneyMod.MODID, value = Dist.CLIENT)
    public static final class GameBus {
        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            while (OPEN_KEY.consumeClick()) {
                if (mc.player != null && mc.screen == null) {
                    PacketDistributor.sendToServer(new OpenPayload());
                }
            }
        }
    }
}
